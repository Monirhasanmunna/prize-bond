<?php
const STATUS_ACTIVE      = 'active';
const STATUS_INACTIVE    = 'inactive';
const ROLE_ADMIN        = 'admin';
const ROLE_USER         = 'user';
